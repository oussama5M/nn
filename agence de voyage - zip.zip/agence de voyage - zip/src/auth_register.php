<?php
// register endpoint (POST)
session_start();
require __DIR__ . '/db.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
if (!$name || !$email || !$password) { http_response_code(400); echo 'missing'; exit; }
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)');
try {
    $stmt->execute([$name,$email,$hash,'user']);
    $_SESSION['user_id'] = $pdo->lastInsertId();
    echo json_encode(['success'=>true]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error'=>'email_taken']);
}
