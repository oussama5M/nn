<?php
// Very simple admin page: list/add circuits & guides
session_start();
require __DIR__ . '/db.php';
require __DIR__ . '/helpers.php';
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
    echo 'Access denied'; exit;
}
// Add circuit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action']==='add_circuit') {
    $title = $_POST['title']; $description = $_POST['description']; $price = $_POST['price']; $duration = $_POST['duration'];
    $stmt = $pdo->prepare('INSERT INTO circuits (title,description,price,duration) VALUES (?,?,?,?)');
    $stmt->execute([$title,$description,$price,$duration]);
    header('Location: admin.php'); exit;
}
$circuits = $pdo->query('SELECT * FROM circuits ORDER BY id DESC')->fetchAll();
?><!doctype html><html><head><meta charset="utf-8"><title>Admin</title></head><body>
<h1>Admin</h1>
<h2>Ajouter Circuit</h2>
<form method="post">
    <input type="hidden" name="action" value="add_circuit">
    <label>Titre <input name="title"></label><br>
    <label>Description <textarea name="description"></textarea></label><br>
    <label>Prix <input name="price" type="number" step="0.01"></label><br>
    <label>Durée <input name="duration"></label><br>
    <button type="submit">Ajouter</button>
</form>
<h2>Circuits</h2>
<ul>
<?php foreach($circuits as $c): ?>
    <li><?php echo e($c['title']); ?> - <a href="circuit_edit.php?id=<?php echo $c['id']; ?>">Edit</a></li>
<?php endforeach; ?>
</ul>
<p><a href="../public/index.php">Voir site</a></p>
</body></html>
