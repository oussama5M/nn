<?php
require __DIR__ . '/../src/db.php';
require __DIR__ . '/../src/helpers.php';
session_start();
$stmt = $pdo->query('SELECT * FROM circuits ORDER BY created_at DESC');
$circuits = $stmt->fetchAll();
?><!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Agence de Voyage - Circuits</title>
</head>
<body>
    <h1>Circuits</h1>
    <?php if(isset($_SESSION['user_id'])): ?>
        <p>Bienvenue — <a href="profile.php">Mon compte</a> | <a href="../src/auth_logout.php">Deconnexion</a></p>
    <?php else: ?>
        <p><a href="login.php">Se connecter</a> | <a href="register.php">S'inscrire</a></p>
    <?php endif; ?>
    <ul>
    <?php foreach($circuits as $c): ?>
        <li>
            <a href="circuit.php?id=<?php echo $c['id']; ?>"><?php echo e($c['title']); ?></a>
            - <?php echo e($c['duration']); ?> - <?php echo number_format($c['price'],2); ?> TND
        </li>
    <?php endforeach; ?>
    </ul>
</body>
</html>
