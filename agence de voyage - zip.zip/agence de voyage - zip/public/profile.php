<?php
require __DIR__ . '/../src/db.php';
require __DIR__ . '/../src/helpers.php';
session_start();
if(!isset($_SESSION['user_id'])){ header('Location: login.php'); exit; }
$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();
$stmt2 = $pdo->prepare('SELECT b.*, c.title FROM bookings b JOIN circuits c ON c.id = b.circuit_id WHERE b.user_id = ? ORDER BY b.created_at DESC');
$stmt2->execute([$_SESSION['user_id']]);
$bookings = $stmt2->fetchAll();
?><!doctype html><html><head><meta charset="utf-8"><title>Mon compte</title></head><body>
<h1>Bonjour <?php echo e($user['name']); ?></h1>
<h2>Mes réservations</h2>
<ul>
<?php foreach($bookings as $bk): ?>
    <li><?php echo e($bk['title']); ?> — <?php echo e($bk['date']); ?> — <?php echo e($bk['status']); ?></li>
<?php endforeach; ?>
</ul>
<p><a href="index.php">Accueil</a> | <a href="../src/auth_logout.php">Deconnexion</a></p>
</body></html>
