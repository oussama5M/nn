<!doctype html>
<html><head><meta charset="utf-8"><title>Register</title></head><body>
<h1>S'inscrire</h1>
<form method="post" action="../src/auth_register.php">
    <label>Nom <input type="text" name="name" required></label><br>
    <label>Email <input type="email" name="email" required></label><br>
    <label>Mot de passe <input type="password" name="password" required></label><br>
    <button type="submit">Créer</button>
</form>
</body></html>
