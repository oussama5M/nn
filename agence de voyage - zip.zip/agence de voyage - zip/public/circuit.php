<?php
require __DIR__ . '/../src/db.php';
require __DIR__ . '/../src/helpers.php';
session_start();
$id = intval($_GET['id'] ?? 0);
if (!$id) { echo 'Invalid'; exit; }
$stmt = $pdo->prepare('SELECT * FROM circuits WHERE id = ?');
$stmt->execute([$id]);
$c = $stmt->fetch();
if (!$c) { echo 'Not found'; exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
    $user_id = $_SESSION['user_id'];
    $date = $_POST['date'] ?? null;
    $seats = intval($_POST['seats'] ?? 1);
    $stmt = $pdo->prepare('INSERT INTO bookings (user_id,circuit_id,date,seats) VALUES (?,?,?,?)');
    $stmt->execute([$user_id,$id,$date,$seats]);
    $msg = 'Réservation envoyée.';
}
?><!doctype html>
<html><head><meta charset="utf-8"><title><?php echo e($c['title']); ?></title></head><body>
<h1><?php echo e($c['title']); ?></h1>
<p><?php echo nl2br(e($c['description'])); ?></p>
<p>Prix: <?php echo number_format($c['price'],2); ?> TND</p>
<p>Durée: <?php echo e($c['duration']); ?></p>
<?php if(isset($msg)): ?><p style="color:green"><?php echo e($msg); ?></p><?php endif; ?>
<h2>Réserver</h2>
<?php if(isset($_SESSION['user_id'])): ?>
<form method="post">
    <label>Date <input type="date" name="date" required></label><br>
    <label>Places <input type="number" name="seats" value="1" min="1"></label><br>
    <button type="submit">Réserver</button>
</form>
<?php else: ?>
    <p>Veuillez <a href="login.php">vous connecter</a> pour réserver.</p>
<?php endif; ?>
<p><a href="index.php">Retour</a></p>
</body></html>
