<!doctype html>
<html><head><meta charset="utf-8"><title>Login</title></head><body>
<h1>Se connecter</h1>
<form method="post" action="../src/auth_login.php" id="loginForm">
    <label>Email <input type="email" name="email" required></label><br>
    <label>Mot de passe <input type="password" name="password" required></label><br>
    <button type="submit">Connexion</button>
</form>
<p><a href="register.php">Créer un compte</a></p>
</body></html>
