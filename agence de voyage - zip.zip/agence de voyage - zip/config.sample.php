<?php
// Copy this file to src/config.php and change settings
return [
    'db_host' => '127.0.0.1',
    'db_name' => 'travel_db',
    'db_user' => 'root',
    'db_pass' => '',
    'db_charset' => 'utf8mb4',
];
