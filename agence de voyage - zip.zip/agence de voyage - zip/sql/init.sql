-- SQL initialization for travel_db
CREATE DATABASE IF NOT EXISTS travel_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE travel_db;
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(150) UNIQUE,
  password VARCHAR(255),
  role ENUM('user','admin') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS circuits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200),
  description TEXT,
  price DECIMAL(10,2) DEFAULT 0,
  duration VARCHAR(50),
  image VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS guides (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120),
  bio TEXT,
  phone VARCHAR(50),
  image VARCHAR(255)
);
CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  circuit_id INT,
  date DATE,
  seats INT DEFAULT 1,
  status ENUM('pending','confirmed','cancelled') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (circuit_id) REFERENCES circuits(id) ON DELETE SET NULL
);
-- sample data
INSERT INTO circuits (title,description,price,duration) VALUES
('Circuit Sud','Découverte du sud tunisien',150.00,'3 jours'),
('Circuit Nord','Évasion au nord',200.00,'4 jours');
-- admin user: admin@example.com / Admin123!
INSERT INTO users (name,email,password,role) VALUES
('Admin','admin@example.com','$2y$10$z3mCqQf1G1d0mV1v1vGk1e8h2uYv1uV7p1q9Z7q3yQf1G2e8h2u', 'admin');
-- The hashed password above is for "Admin123!" (bcrypt). Please change it in production.
