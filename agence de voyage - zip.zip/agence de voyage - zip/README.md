# Travel Agency - PHP + MySQL Starter Backend

**What is inside**
- `public/` : place your front-end files here (index.php, circuit.php, guides.php...)
- `src/` : backend PHP logic (db.php, auth, bookings, admin)
- `sql/init.sql` : SQL to create database, tables and sample rows
- `config.sample.php` : DB config example (copy to config.php and edit)
- `install_instructions.txt` : quick install steps

**Default admin credentials (change immediately)**
- email: admin@example.com
- password: Admin123!

**Quick install (local XAMPP / MAMP / LAMP)**
1. Copy the project into your webroot (e.g. `htdocs/` for XAMPP) or set virtual host to `public/` folder.
2. Create a MySQL database named `travel_db` (or change name in `config.php`).
3. Import `sql/init.sql` into the database.
4. Copy `config.sample.php` to `src/config.php` and update DB credentials.
5. Open the site in a browser (e.g. http://localhost/yourproject/public/).

**Notes**
- This is a starter template. For production, secure sessions, use HTTPS, validate inputs, and sanitize outputs.
